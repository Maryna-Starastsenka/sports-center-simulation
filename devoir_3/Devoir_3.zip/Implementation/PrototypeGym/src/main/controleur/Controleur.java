package main.controleur;

/**
 * Classe abstraite du contrôleur
 * @author Maryna Starastsenka
 * @author Alex Defoy
 */
public abstract class Controleur {
}
